import os

print(os.name)
print(os.system("dir"))
print(os.getenv("PATH"))
print(os.sys.exit(1))
print("M still here")   # This won't get printed on screen.