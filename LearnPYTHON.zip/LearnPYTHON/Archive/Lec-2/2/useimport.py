import function

print(function.add(10,20))