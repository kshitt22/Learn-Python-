from math2 import mathematics

m2 = mathematics.add(10,20)
print(m2)