import fun

num1=int(input("Enter any num1 : "))
num2=int(input("Enter any num2 : "))
print(fun.add(num1,num2))
print(fun.sub(num1,num2))
print(fun.mul(num1,num2))
print(fun.div(num1,num2))