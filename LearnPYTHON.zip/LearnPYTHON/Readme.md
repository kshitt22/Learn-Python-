- [Lab-1](./Lab-1/Readme.md)
    - Installation
    - Data types

- [Lab-2](./Lab-2/Readme.md)
    - Data Manipulation - I
        - Format function
        - Use of Index Postion
        - Index function

- [Lab-3](./Lab-3/Readme.md)
    - Data Manipulation - II
        - Take input from user
        - Change case
        - Find function
        - Len function
        - Strip function
    - Operators in Python
        - Arithmetic Operators
        - Assignment Operators
        - Comparison Operators
        - Logical Operators
        - Identity Operators
        - Membership Operators
        - Bitwise Operators

- [Lab-4](./Lab-4/Readme.md)
    - Data Manipulation - III
        - List manipulation
            - use index postioning
            - append() function
            - insert() function
            - extend() function
            - remove() function
            - range() function
            - value re-assign
        - Tuple manipulation
            - index() function
            - count() function
        - Set manipulation
            - add() function
            - update() function
            - pop() function
            - remove() function
        - Dictionary manipulation
            - get() function
            - value re-assign
            - update() function
            - pop() function
            - items() function
            - keys() function
        
- [Lab-5](./Lab-5/Readme.md)
    - Condition with python

- [Lab-6](./Lab-6/Readme.md)
    - *for* Loop with python
    - *continue* and *break* keyword

- [Lab-7](./Lab-7/Readme.md)
    - *while* loop with python

- [Lab-8](./Lab-8/Readme.md)
    - *function* with python